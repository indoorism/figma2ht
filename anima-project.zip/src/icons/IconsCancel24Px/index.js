export { IconsCancel24Px } from "./IconsCancel24Px";
