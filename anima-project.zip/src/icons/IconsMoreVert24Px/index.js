export { IconsMoreVert24Px } from "./IconsMoreVert24Px";
