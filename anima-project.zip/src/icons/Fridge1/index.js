export { Fridge1 } from "./Fridge1";
