export { IconsMenu24Px } from "./IconsMenu24Px";
