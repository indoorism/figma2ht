export { IconsArrowBack24Px } from "./IconsArrowBack24Px";
