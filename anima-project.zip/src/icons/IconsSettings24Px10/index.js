export { IconsSettings24Px10 } from "./IconsSettings24Px10";
