export { Icon7 } from "./Icon7";
