export { IconsSettings24Px11 } from "./IconsSettings24Px11";
