export { Icon20 } from "./Icon20";
