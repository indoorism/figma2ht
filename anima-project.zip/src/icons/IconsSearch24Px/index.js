export { IconsSearch24Px } from "./IconsSearch24Px";
