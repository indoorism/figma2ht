export { IconsToday24Px } from "./IconsToday24Px";
