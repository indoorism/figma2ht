export { IconsAttachFile24Px } from "./IconsAttachFile24Px";
