export { Fridge } from "./Fridge";
