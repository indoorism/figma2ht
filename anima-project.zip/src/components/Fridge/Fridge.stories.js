import { Fridge } from ".";

export default {
  title: "Components/Fridge",
  component: Fridge,
};

export const Default = {
  args: {},
};
